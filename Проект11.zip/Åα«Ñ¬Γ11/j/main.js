$(function(){
$("#loading").hide();
$(document).on("ajaxSend", function() {
    $("#loading").show(); // 
}).on("ajaxStop", function(){
    $("#loading").hide(); // 
});
/////////////////////////////////////////
var newsurl = "https://www.oa.edu.ua/getnews";
$(".news").load(newsurl + " .news-items");
$(".events").load(newsurl + " .event-items");

$(".news").on("click", "a[href^=https]", function() {
  var url = $(this).attr("href");
  $(".news").load(url + " .main ", function(data) {
    $(".news .main a").replaceWith(function() {
    return this.childNodes;	});
  });
return false;
});
$(".events").on("click", "a[href^=https]", function() {
  var url = $(this).attr("href");
    $(".events").load(url + " main, .main ", function(data) {
    $(".events main .mec-event-content a").replaceWith(function() {
    return this.childNodes;	});
  });
return false;
});

$(".backnews").on("click", function() {
    $(".news").load(newsurl + " .news-items");
return false;
});
$(".backevents").on("click", function() {
    $(".events").load(newsurl + " .event-items");
return false;
});

///////////////////////////////////////////

  $("#owl-one").owlCarousel({
   //loop:true,
   rewind:true,
    items: 1,
	touchDrag:true,
	mouseDrag:false,
	nav:true,
	//pullDrag:false,
	autoplay:1,
	autoplayTimeout: 15000,
	dotsSpeed:300,
    //nav:true,
	//URLhashListener:true,
        autoplayHoverPause:true,
        //startPosition: 'URLHash',
//autoHeight:true,
   
    });

 $('[data-fancybox="gallery"]').fancybox({
  buttons: [
    "zoom",
    "close"
  ],
});

/*var timer;
 $( "#pills-plan-tab" ).click(function() {   
  clearTimeout(timer);
  timer = setTimeout(function () { $('#pills-news-tab').trigger('click');}, 60000);
  });
  $( "#pills-home-tab" ).click(function() {   
  clearTimeout(timer);
  timer = setTimeout(function () { $('#pills-news-tab').trigger('click');}, 120000);
  });*/
 $( "#pills-news-tab" ).click(function() {   
 // clearTimeout(timer);
  $(".news").load(newsurl + " .news-items");
  $(".events").load(newsurl + " .event-items");
  });
    
});

/*модалне вікно*/
var modal = document.getElementById('myModal');


var btn = document.getElementById("myBtn");


var span = document.getElementsByClassName("close")[0];


btn.onclick = function() {
    modal.style.display = "block";
}


span.onclick = function() {
    modal.style.display = "none";
}


window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

//*модальне вікно 2
var modal1 = document.getElementById('myModal1');


var btn1 = document.getElementById("myBtn1");


var span1 = document.getElementsByClassName("close1")[0];


btn1.onclick = function() {
    modal1.style.display = "block";
}


span1.onclick = function() {
    modal1.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}

//*модальне вікно 3
var modal2 = document.getElementById('myModal2');


var btn2 = document.getElementById("myBtn2");


var span2 = document.getElementsByClassName("close2")[0];


btn2.onclick = function() {
    modal2.style.display = "block";
}


span2.onclick = function() {
    modal2.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}
//*модальне вікно 4
var modal3 = document.getElementById('myModal3');


var btn3 = document.getElementById("myBtn3");


var span3 = document.getElementsByClassName("close3")[0];


btn3.onclick = function() {
    modal3.style.display = "block";
}


span3.onclick = function() {
    modal3.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}
//*модальне вікно 5
var modal4 = document.getElementById('myModal4');


var btn4 = document.getElementById("myBtn4");


var span4 = document.getElementsByClassName("close4")[0];


btn4.onclick = function() {
    modal4.style.display = "block";
}


span4.onclick = function() {
    modal4.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}
//*модальне вікно 6
var modal5 = document.getElementById('myModal5');


var btn5 = document.getElementById("myBtn5");


var span5 = document.getElementsByClassName("close5")[0];


btn5.onclick = function() {
    modal5.style.display = "block";
}


span5.onclick = function() {
    modal5.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}

//*модальне вікно 7
var modal6 = document.getElementById('myModal6');


var btn6 = document.getElementById("myBtn6");


var span6 = document.getElementsByClassName("close6")[0];


btn6.onclick = function() {
    modal6.style.display = "block";
}


span6.onclick = function() {
    modal6.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}
//*модальне вікно 8
var modal7 = document.getElementById('myModal7');


var btn7 = document.getElementById("myBtn7");


var span7 = document.getElementsByClassName("close7")[0];


btn7.onclick = function() {
    modal7.style.display = "block";
}


span7.onclick = function() {
    modal7.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}
//*модальне вікно 9
var modal8 = document.getElementById('myModal8');


var btn8 = document.getElementById("myBtn8");


var span8 = document.getElementsByClassName("close8")[0];


btn8.onclick = function() {
    modal8.style.display = "block";
}


span8.onclick = function() {
    modal8.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
      modal.style.display = "none";
  }
}