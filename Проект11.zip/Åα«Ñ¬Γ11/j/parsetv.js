$(function() {

    var baseUrl = "https://dekanat.oa.edu.ua/api";
    //$(".select2").select2();
    function addHeader(lessons, countRows, ttplace) {
        var rows = "<thead>";
        for (var i = 0; i < countRows; i++) {
            rows += "<tr>";
            for (var j = 0; j < lessons[i].length; j++) {
                var item = lessons[i][j];
                rows += "<th class='text-center' colspan=" + item.colSpan + " rowspan="+item.rowSpan+">";
                rows+= item.value
                   rows += "</th>";
            }
            rows += "</tr>";
        }
        rows += "</thead>";
        $(ttplace).append(rows);
    }
      function addBody(lessons, countRows, ttplace) {
          var rows = "<tbody>";
          for (var i = countRows; i < lessons.length; i++) {
            rows += "<tr>";
            for (var j = 0; j < lessons[i].length; j++) {
                var item = lessons[i][j];
                if (item.lessons.length > 0) {
                   
                    rows += "<td class='text-center' colspan=" + item.colSpan + " rowspan=" + item.rowSpan + ">";
                    for (var k = 0; k < item.lessons.length; k++) {
                        var lesson = item.lessons[k];
                        rows += "<div class='text-center'  style='background-color: " + lesson.color + "'>";
                        rows += '<span>' + lesson.discipline + '</span>';
                        rows += '<span>' + lesson.lessonType + '</span>';
                        rows += ' <span class="text-small">' + lesson.number + '</span>';
                        rows += '<span class="text-small">' + lesson.maxNumber + '</span>';
                        rows += ' <span class="text-small">' + lesson.teacher + '</span>';
                        rows += '<em>' + lesson.audience + '</em>';
                        rows += '</div>';
                    }
                   
                } else {
                      rows += "<td class='text-center' colspan=" + item.colSpan + " rowspan="+item.rowSpan+" style='width:1% !important'>";
                    rows += item.value;
                }
                   rows += "</td>";
            }
            rows += "</tr>";
        }
        rows += "</tbody>";
        $(ttplace).append(rows);
    }
    

    function loadTImetable() {
      
       /*  $.get(baseUrl + "/v1/university/weeks4Select", function (data) {
            week = data.filter(i => i.isSelected);
        });*/
        var week = "";
        $.get(baseUrl + "/v1/university/weeks4Select", function (data) {
               week = $.map(data, function(data) {
                   if(data.isSelected==true)
                       return data.value; // or return obj.name
               });
       });
        
        $.get(baseUrl + "/v1/timetable/faculty?week=" + week + "&year=" + 1 + "&specialities=" + spec1, function (data) {
            var countRows = 0;
            var ttplace = "#timetable1";
            for (var i = countRows; i < data.length; i++) {
              if(data[i][0].isHeader)  countRows += 1;
            }
            addHeader(data, countRows, ttplace);
            addBody(data,countRows, ttplace)
    });
       $.get(baseUrl + "/v1/timetable/faculty?week=" + week + "&year=" + 2 + "&specialities=" + spec2, function (data) {
           var countRows = 0;
           var ttplace = "#timetable2";
           for (var i = countRows; i < data.length; i++) {
           if(data[i][0].isHeader)  countRows += 1;
           }
           addHeader(data, countRows, ttplace);
           addBody(data,countRows, ttplace)
   });
   $.get(baseUrl + "/v1/timetable/faculty?week=" + week + "&year=" + 3 + "&specialities=" + spec3, function (data) {
       /* $("#timetable,#timetable2").empty();*/
        var countRows = 0;
        var ttplace = "#timetable3";
        for (var i = countRows; i < data.length; i++) {
        if(data[i][0].isHeader)  countRows += 1;
        }
        addHeader(data, countRows, ttplace);
        addBody(data,countRows, ttplace)
   });
   $.get(baseUrl + "/v1/timetable/faculty?week=" + week + "&year=" + 4 + "&specialities=" + spec4, function (data) {
        var countRows = 0;
        var ttplace = "#timetable4";
        for (var i = countRows; i < data.length; i++) {
        if(data[i][0].isHeader)  countRows += 1;
        }
        addHeader(data, countRows, ttplace);
        addBody(data,countRows, ttplace)
   });
   $.get(baseUrl + "/v1/timetable/faculty?week=" + week + "&year=" + 5 + "&specialities=" + spec5, function (data) {
        var countRows = 0;
        var ttplace = "#timetable5";
        for (var i = countRows; i < data.length; i++) {
        if(data[i][0].isHeader)  countRows += 1;
        }
        addHeader(data, countRows, ttplace);
        addBody(data,countRows, ttplace)
     });
  }

        loadTImetable();

});

$(function() {
    // Owl Carousel
    var owl = $(".owl-carousel");
    owl.owlCarousel({
      items: 1,
      margin: 10,
      loop: true,
      nav: true
    });
  });
  